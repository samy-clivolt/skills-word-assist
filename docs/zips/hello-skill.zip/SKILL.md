---
name: hello-skill
description: Skill de test minimal pour valider le registre.
---

# Hello Skill

Skill de test minimal pour verifier installation et detection.

## Quand l'utiliser

- Pour tester le registre
- Pour verifier l'installation

## Etapes

1. Dire bonjour
2. Expliquer le next step
