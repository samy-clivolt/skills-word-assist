---
name: ops-checklist
description: Checklist ops simple pour validations rapides.
---

# Ops Checklist

Checklist rapide pour operations courantes.

## Quand l'utiliser

- Avant une mise en production
- Pour valider un runbook

## Etapes

1. Verifier les logs
2. Verifier les alertes
3. Confirmer les dependances
