---
name: summary-helper
description: Resume un document ou une reunion en points actionnables.
---

# Summary Helper

Resume un contenu en elements cles et actions.

## Quand l'utiliser

- Pour condenser un document long
- Pour preparer une synthese

## Etapes

1. Extraire les points cles
2. Lister les actions
3. Proposer un resume court
